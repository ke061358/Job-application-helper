import AppKit
import Foundation
import Vision

struct OCRLine: Codable {
    let text: String
    let x: Double
    let y: Double
    let width: Double
    let height: Double
    let confidence: Float
}

struct OCRPayload: Codable {
    let rowText: String
    let columnText: String
    let lines: [OCRLine]
}

if CommandLine.arguments.count < 2 {
    fputs("missing image path\n", stderr)
    exit(2)
}

let imageURL = URL(fileURLWithPath: CommandLine.arguments[1])
guard let image = NSImage(contentsOf: imageURL) else {
    fputs("failed to open image\n", stderr)
    exit(3)
}

var proposedRect = NSRect(origin: .zero, size: image.size)
guard let cgImage = image.cgImage(forProposedRect: &proposedRect, context: nil, hints: nil) else {
    fputs("failed to decode image\n", stderr)
    exit(4)
}

let request = VNRecognizeTextRequest()
request.recognitionLevel = .accurate
request.usesLanguageCorrection = true
request.recognitionLanguages = ["zh-Hans", "en-US"]

let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

do {
    try handler.perform([request])
} catch {
    fputs("ocr failed: \(error.localizedDescription)\n", stderr)
    exit(5)
}

let observations = request.results ?? []
let lines = observations.compactMap { observation -> OCRLine? in
    guard let candidate = observation.topCandidates(1).first else {
        return nil
    }
    let text = candidate.string.trimmingCharacters(in: .whitespacesAndNewlines)
    if text.isEmpty {
        return nil
    }
    let box = observation.boundingBox
    return OCRLine(
        text: text,
        x: Double(box.minX),
        y: Double(box.minY),
        width: Double(box.width),
        height: Double(box.height),
        confidence: candidate.confidence
    )
}

func rowSorted(_ input: [OCRLine]) -> [OCRLine] {
    input.sorted { lhs, rhs in
        let yDelta = abs((lhs.y + lhs.height / 2) - (rhs.y + rhs.height / 2))
        if yDelta > 0.015 {
            return lhs.y > rhs.y
        }
        return lhs.x < rhs.x
    }
}

func columnSorted(_ input: [OCRLine]) -> [OCRLine] {
    let ordered = input.sorted { lhs, rhs in
        if abs(lhs.x - rhs.x) > 0.08 {
            return lhs.x < rhs.x
        }
        return lhs.y > rhs.y
    }
    var columns: [[OCRLine]] = []
    for line in ordered {
        var targetIndex: Int?
        for index in columns.indices {
            let avgX = columns[index].map { $0.x }.reduce(0, +) / Double(columns[index].count)
            if abs(line.x - avgX) < 0.12 {
                targetIndex = index
                break
            }
        }
        if let index = targetIndex {
            columns[index].append(line)
        } else {
            columns.append([line])
        }
    }
    columns.sort { lhs, rhs in
        let lhsX = lhs.map { $0.x }.min() ?? 0
        let rhsX = rhs.map { $0.x }.min() ?? 0
        return lhsX < rhsX
    }
    return columns.flatMap { column in
        column.sorted { lhs, rhs in
            let yDelta = abs((lhs.y + lhs.height / 2) - (rhs.y + rhs.height / 2))
            if yDelta > 0.015 {
                return lhs.y > rhs.y
            }
            return lhs.x < rhs.x
        }
    }
}

let rowText = rowSorted(lines).map(\.text).joined(separator: "\n")
let columnText = columnSorted(lines).map(\.text).joined(separator: "\n")

if CommandLine.arguments.contains("--json") {
    let payload = OCRPayload(rowText: rowText, columnText: columnText, lines: lines)
    let encoder = JSONEncoder()
    encoder.outputFormatting = [.withoutEscapingSlashes]
    do {
        let data = try encoder.encode(payload)
        print(String(data: data, encoding: .utf8) ?? rowText)
    } catch {
        print(rowText)
    }
} else {
    print(rowText)
}
