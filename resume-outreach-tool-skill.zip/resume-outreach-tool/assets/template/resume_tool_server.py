#!/usr/bin/env python3
import base64
import html
import io
import json
import os
import re
import shutil
import socketserver
import subprocess
import sys
import tempfile
import zipfile
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlparse
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
HTML_FILE = ROOT / "resume-outreach-tool.html"
OCR_SCRIPT = ROOT / "ocr_image.swift"
OCR_BINARY = ROOT / "ocr_image"
PORT = 8765
HOST = os.environ.get("HOST", "127.0.0.1")
BUNDLED_SITE_PACKAGES = Path.home() / ".cache/codex-runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages"
AI_BASE_URL = os.environ.get("AI_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1").rstrip("/")
AI_API_KEY = os.environ.get("AI_API_KEY", "")
AI_TEXT_MODEL = os.environ.get("AI_TEXT_MODEL", "qwen-plus")
AI_VISION_MODEL = os.environ.get("AI_VISION_MODEL", "qwen-vl-plus")
AI_TIMEOUT = int(os.environ.get("AI_TIMEOUT", "60"))

if BUNDLED_SITE_PACKAGES.exists():
    sys.path.insert(0, str(BUNDLED_SITE_PACKAGES))


class PageTextParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip_stack = []
        self.title_parts = []
        self.text_parts = []
        self.meta = {}
        self.in_title = False

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        attrs_dict = {k.lower(): v for k, v in attrs if k}
        if tag in {"script", "style", "noscript", "svg", "canvas"}:
            self.skip_stack.append(tag)
        if tag == "title":
            self.in_title = True
        if tag == "meta":
            key = attrs_dict.get("property") or attrs_dict.get("name")
            content = attrs_dict.get("content")
            if key and content:
                self.meta[key.lower()] = html.unescape(content).strip()

    def handle_endtag(self, tag):
        tag = tag.lower()
        if self.skip_stack and self.skip_stack[-1] == tag:
            self.skip_stack.pop()
        if tag == "title":
            self.in_title = False

    def handle_data(self, data):
        text = data.strip()
        if not text:
            return
        if self.in_title:
            self.title_parts.append(text)
        if not self.skip_stack:
            self.text_parts.append(text)

    @property
    def title(self):
        return clean_text(" ".join(self.title_parts))

    @property
    def visible_text(self):
        return clean_text("\n".join(self.text_parts))


def clean_text(value):
    value = html.unescape(value or "")
    value = re.sub(r"\r", "\n", value)
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n[ \t]+", "\n", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def truncate_text(value, limit):
    value = clean_text(value)
    return value[:limit] if len(value) > limit else value


def ai_options_from_payload(payload):
    config = payload.get("aiConfig") if isinstance(payload, dict) else None
    if not isinstance(config, dict):
        return {}
    return {
        "apiKey": clean_text(config.get("apiKey", "")),
        "baseUrl": clean_text(config.get("baseUrl", "")),
        "textModel": clean_text(config.get("textModel", "")),
        "visionModel": clean_text(config.get("visionModel", "")),
    }


def ai_enabled(ai_options=None):
    ai_options = ai_options or {}
    return bool(ai_options.get("apiKey") or AI_API_KEY)


def extract_json_object(text):
    text = clean_text(text)
    if not text:
        raise ValueError("模型没有返回内容")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, flags=re.S)
    if fenced:
        return json.loads(fenced.group(1))

    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        return json.loads(text[start : end + 1])
    raise ValueError("模型返回不是可解析 JSON")


def ai_chat(model, messages, max_tokens=1800, temperature=0.2, ai_options=None):
    ai_options = ai_options or {}
    api_key = ai_options.get("apiKey") or AI_API_KEY
    base_url = (ai_options.get("baseUrl") or AI_BASE_URL).rstrip("/")
    if not api_key:
        raise ValueError("未配置 AI_API_KEY，无法调用云端大模型")
    body = json.dumps(
        {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        },
        ensure_ascii=False,
    ).encode("utf-8")
    request = Request(
        f"{base_url}/chat/completions",
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=AI_TIMEOUT) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"AI 调用失败：{exc.code} {detail[:400]}")
    except URLError as exc:
        raise RuntimeError(f"AI 网络请求失败：{exc.reason}")

    try:
        return payload["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise RuntimeError(f"AI 返回格式异常：{json.dumps(payload, ensure_ascii=False)[:500]}")


def ai_extract_job_from_image(data_url, ai_options=None):
    ai_options = ai_options or {}
    prompt = (
        "你是招聘岗位截图识别助手。请从截图中提取岗位信息，只返回 JSON，不要解释。"
        "字段：company, role, salary, city, experience, education, jd, tags, confidence, needsReview。"
        "如果截图是 Boss/猎聘等左右布局，右侧通常是岗位详情，左侧是岗位列表。"
        "岗位名、薪资、城市、经验、学历优先读右侧详情页顶部。"
        "company 是非必填字段，如果无法确定真实公司名就返回空字符串，不要猜。"
        "公司名如果右侧详情没有展示，优先读取左侧被选中/高亮岗位卡片底部的公司名。"
        "不要读取未选中的岗位卡片，不要把招聘顾问、猎头公司、联系人姓名、刚刚活跃、立即沟通、收藏、去App、BOSS 等按钮或平台文案当成公司。"
        "如果选中卡片公司是“某大型公司/某品牌方/上市公司”等匿名描述，请保留原文。"
        "jd 只保留职位描述、职位详情、职位信息、岗位职责、职责信息、任职要求等正文原文，不要改写。"
        "缺失字段用空字符串，tags 和 needsReview 为字符串数组，confidence 是 0-100 整数。"
    )
    content = ai_chat(
        ai_options.get("visionModel") or AI_VISION_MODEL,
        [
            {"role": "system", "content": "你只输出合法 JSON。"},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": data_url}},
                ],
            },
        ],
        max_tokens=2600,
        temperature=0.1,
        ai_options=ai_options,
    )
    data = extract_json_object(content)
    return normalize_job_result({
        "ok": True,
        "company": clean_text(data.get("company", "")),
        "role": clean_text(data.get("role", "")),
        "salary": clean_text(data.get("salary", "")),
        "city": clean_text(data.get("city", "")),
        "experience": clean_text(data.get("experience", "")),
        "education": clean_text(data.get("education", "")),
        "jd": clean_text(data.get("jd", "")),
        "tags": data.get("tags") if isinstance(data.get("tags"), list) else [],
        "confidence": data.get("confidence", 0),
        "needsReview": data.get("needsReview") if isinstance(data.get("needsReview"), list) else [],
        "source": "ai_vision",
    })


def ai_analyze_resume_text(name, text, ai_options=None):
    ai_options = ai_options or {}
    prompt = {
        "task": "请分析这份简历，只返回 JSON。",
        "schema": {
            "summary": "一句话个人定位",
            "tags": ["最多8个能力标签"],
            "proof": ["最多5条可用于求职话术的量化结果或项目亮点"],
            "roleDirections": ["适合投递的岗位方向"],
        },
        "resumeName": name,
        "resumeText": truncate_text(text, 18000),
    }
    content = ai_chat(
        ai_options.get("textModel") or AI_TEXT_MODEL,
        [
            {"role": "system", "content": "你是简历分析助手，只输出合法 JSON，不要编造经历。"},
            {"role": "user", "content": json.dumps(prompt, ensure_ascii=False)},
        ],
        max_tokens=1800,
        temperature=0.2,
        ai_options=ai_options,
    )
    data = extract_json_object(content)
    return {
        "summary": clean_text(data.get("summary", "")),
        "tags": (data.get("tags") or [])[:8] if isinstance(data.get("tags"), list) else [],
        "proof": (data.get("proof") or [])[:5] if isinstance(data.get("proof"), list) else [],
        "roleDirections": (data.get("roleDirections") or [])[:6] if isinstance(data.get("roleDirections"), list) else [],
    }


def clean_material(value):
    value = clean_text(value)
    value = re.sub(r"[?？]+", "", value)
    value = re.sub(r"[。！？!；;，,、\s]+$", "", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def clean_message_text(value):
    value = clean_text(value)
    value = re.sub(r"(?:薪资区间|薪资|月薪|日薪)\s*[\d.]+\s*(?:[-~—–]\s*[\d.]+)?\s*(?:[Kk万]|元/天|/天)?", "", value)
    value = re.sub(r"\d+\s*(?:[-~—–]\s*\d+)?\s*[Kk]\b", "", value)
    value = value.replace("？", "。").replace("?", "。")
    value = re.sub(r"([。！？；，])\1+", r"\1", value)
    value = re.sub(r"[；;]。", "。", value)
    value = re.sub(r"，。", "。", value)
    value = re.sub(r"。\s*。", "。", value)
    value = re.sub(r"\s+", "", value)
    return value.strip("；;，,、 ")


def material_list(value, limit=4):
    if isinstance(value, list):
        source = value
    elif value:
        source = re.split(r"[；;\n、]", str(value))
    else:
        source = []
    items = []
    for item in source:
        clean = clean_material(str(item))
        if clean and clean not in items:
            items.append(clean)
    return items[:limit]


def first_material(values, fallback):
    for value in values:
        clean = clean_material(value)
        if clean:
            return clean
    return fallback


def join_materials(items, fallback, limit=3):
    clean_items = material_list(items, limit)
    return "、".join(clean_items) if clean_items else fallback


def resume_material_from_payload(payload):
    proof = []
    tags = []
    summaries = []
    for item in (payload.get("resumes") or [])[:3]:
        proof.extend(material_list(item.get("proof"), 3))
        tags.extend(material_list(item.get("tags"), 6))
        summary = clean_material(item.get("summary", ""))
        if summary:
            summaries.append(summary)
    return {
        "proof": list(dict.fromkeys(proof))[:5],
        "tags": list(dict.fromkeys(tags))[:8],
        "summary": first_material(summaries, ""),
    }


def build_hybrid_messages(data, payload):
    job = payload.get("job") or {}
    role = clean_material(job.get("role", ""))
    role_text = f"「{role}」岗位" if role else "这个岗位"
    resume_fallback = resume_material_from_payload(payload)

    job_tags = material_list(data.get("jdKeywords"), 6) or material_list(data.get("jobTags"), 6)
    match_tags = material_list(data.get("matchTags"), 6) or resume_fallback["tags"]
    problems = material_list(data.get("jobProblem"), 4)
    evidence = material_list(data.get("resumeEvidence"), 4) or resume_fallback["proof"]
    main_selling_point = clean_material(data.get("mainSellingPoint", ""))

    keyword_text = join_materials(job_tags, "岗位核心要求", 3)
    match_text = join_materials(match_tags, "相关岗位能力", 3)
    problem_text = first_material(problems, f"{keyword_text}相关目标的落地和结果提升")
    problem_short = first_material(problems[:1], keyword_text)
    evidence_text = first_material(evidence, main_selling_point or resume_fallback["summary"] or "我过往在相关项目中有积累")
    evidence_sentence = f"过往经历中，{evidence_text}。"

    messages = {
        "boss": [
            {
                "title": "解决问题型",
                "text": f"您好，我想了解贵司{role_text}。我理解这个岗位重点不是单点执行，而是围绕{problem_text}形成稳定结果。我过往在{keyword_text}上有相关积累，{evidence_sentence}如果需要能把问题拆成动作并推动结果的人，我希望有机会进一步沟通。",
            },
            {
                "title": "结果价值型",
                "text": f"您好，我想投递{role_text}。结合 JD，我理解岗位更看重{keyword_text}，最终要把{problem_short}做出结果。过往经历中，{evidence_text}，能从目标拆解、过程推进到复盘优化持续跟进。期待和您进一步沟通岗位匹配。",
            },
        ],
        "hr": [
            {
                "title": "关键词匹配型",
                "text": f"您好，我想投递贵司{role_text}。我和 JD 中的{keyword_text}匹配度较高，过往也有{evidence_text}。如果岗位正在看相关背景的候选人，辛苦帮忙看下我的简历，期待进一步沟通。",
            },
            {
                "title": "简洁投递型",
                "text": f"您好，我对{role_text}比较感兴趣。我的经历主要覆盖{match_text}，与岗位要求的{keyword_text}有交集。{evidence_sentence}简历已整理好，期待获得一次沟通机会。",
            },
        ],
        "leader": [
            {
                "title": "业务落地型",
                "text": f"您好，我想了解{role_text}。我理解这个岗位需要把{problem_text}落到具体动作，而不只是执行事项。我过往做过{keyword_text}相关工作，{evidence_sentence}可以从目标拆解、资源协同、过程复盘推进到业务结果。",
            },
            {
                "title": "经验复盘型",
                "text": f"您好，我对{role_text}感兴趣。我的优势是能把业务问题拆成策略、流程、协同和数据复盘几件事推进，围绕{problem_short}持续优化。过往经历里，{evidence_text}，我认为这部分经验能较快对接岗位需要。",
            },
        ],
    }
    for group in messages.values():
        for item in group:
            item["text"] = clean_message_text(item["text"])
    return messages


def ai_generate_application(payload):
    ai_options = ai_options_from_payload(payload)
    prompt = {
        "task": "根据岗位信息和简历内容，提取求职匹配分析素材。只返回 JSON，不要 Markdown，不要生成最终打招呼话术。",
        "requirements": [
            "不要编造简历中不存在的经历、公司、学历、数字。",
            "不要输出 messages 字段，最终话术会由系统模板生成。",
            "不要提薪资、薪资区间、日薪或月薪。",
            "jobProblem 必须来自 JD 中的岗位职责、任职要求或业务目标，不能空泛。",
            "jdKeywords 必须使用 JD 原词或非常接近的业务词。",
            "resumeEvidence 必须来自简历真实内容，如果证据不足，用保守表达，不要补数字。",
            "mainSellingPoint 用一句话概括候选人最适合主打的卖点。",
            "messageStrategy 分别说明 Boss/HR/业务负责人最应该听到什么，不要写完整话术。",
            "清理重复标点，不要出现。。、；。、，。",
        ],
        "schema": {
            "score": "0-100整数",
            "applyAdvice": {"level": "强烈建议/建议投递/可以尝试/谨慎投递/待补充", "degree": "0-100整数", "reason": "一句话原因"},
            "jobTags": ["岗位关键词，最多12个"],
            "jdKeywords": ["JD 原词或近义业务关键词，最多8个"],
            "matchTags": ["候选人匹配标签，最多8个"],
            "jobProblem": ["岗位真实要解决的问题，2-4条"],
            "resumeEvidence": ["从简历中抽取的真实证据，2-4条"],
            "mainSellingPoint": "一句话主打卖点",
            "messageStrategy": {"boss": "解决问题策略", "hr": "关键词匹配策略", "leader": "业务价值策略"},
            "insight": "一段匹配洞察",
        },
        "job": payload.get("job", {}),
        "resumes": [
            {
                "name": item.get("name", ""),
                "summary": item.get("summary", ""),
                "tags": item.get("tags", []),
                "proof": item.get("proof", []),
                "text": truncate_text(item.get("text", ""), 12000),
            }
            for item in (payload.get("resumes") or [])[:3]
        ],
    }
    content = ai_chat(
        ai_options.get("textModel") or AI_TEXT_MODEL,
        [
            {"role": "system", "content": "你是中文求职投递助手，只输出合法 JSON。"},
            {"role": "user", "content": json.dumps(prompt, ensure_ascii=False)},
        ],
        max_tokens=3200,
        temperature=0.35,
        ai_options=ai_options,
    )
    data = extract_json_object(content)
    data["jobTags"] = material_list(data.get("jobTags"), 12)
    data["jdKeywords"] = material_list(data.get("jdKeywords"), 8)
    data["matchTags"] = material_list(data.get("matchTags"), 8)
    data["jobProblem"] = material_list(data.get("jobProblem"), 4)
    data["resumeEvidence"] = material_list(data.get("resumeEvidence"), 4)
    data["mainSellingPoint"] = clean_material(data.get("mainSellingPoint", ""))
    data["messages"] = build_hybrid_messages(data, payload)
    data["ok"] = True
    data["source"] = "ai_material_hybrid"
    data["hybrid"] = True
    return data


def ai_test_config(payload):
    ai_options = ai_options_from_payload(payload)
    if not ai_options.get("apiKey") or not ai_options.get("baseUrl") or not ai_options.get("textModel"):
        raise ValueError("缺少 API Key、接口地址或文本模型")
    content = ai_chat(
        ai_options["textModel"],
        [
            {"role": "system", "content": "你是 API 连通性测试助手。"},
            {"role": "user", "content": "请只回复 OK"},
        ],
        max_tokens=8,
        temperature=0,
        ai_options=ai_options,
    )
    if not clean_text(content):
        raise ValueError("模型没有返回内容")
    return {"ok": True}


def strip_html(value):
    parser = PageTextParser()
    try:
        parser.feed(value or "")
    except Exception:
        return clean_text(re.sub(r"<[^>]+>", " ", value or ""))
    return parser.visible_text


def find_json_ld(html_text):
    blocks = re.findall(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html_text,
        flags=re.I | re.S,
    )
    candidates = []
    for block in blocks:
        body = html.unescape(block).strip()
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            continue
        candidates.extend(flatten_json_ld(data))
    return candidates


def flatten_json_ld(data):
    items = []
    if isinstance(data, list):
        for item in data:
            items.extend(flatten_json_ld(item))
    elif isinstance(data, dict):
        items.append(data)
        graph = data.get("@graph")
        if isinstance(graph, list):
            for item in graph:
                items.extend(flatten_json_ld(item))
    return items


def is_job_posting(item):
    kind = item.get("@type") if isinstance(item, dict) else None
    if isinstance(kind, list):
        return any(str(x).lower() == "jobposting" for x in kind)
    return str(kind).lower() == "jobposting"


def text_from_json_value(value):
    if isinstance(value, dict):
        return value.get("name") or value.get("text") or value.get("@value") or ""
    if isinstance(value, list):
        return " ".join(text_from_json_value(x) for x in value)
    return str(value or "")


def extract_structured(html_text):
    for item in find_json_ld(html_text):
        if not is_job_posting(item):
            continue
        company = ""
        org = item.get("hiringOrganization") or item.get("organization")
        if isinstance(org, dict):
            company = org.get("name") or ""
        elif isinstance(org, str):
            company = org
        role = text_from_json_value(item.get("title"))
        description = strip_html(text_from_json_value(item.get("description")))
        return {
            "company": clean_text(company),
            "role": clean_text(role),
            "jd": clean_text(description),
            "source": "json_ld",
        }
    return None


ROLE_SUFFIXES = (
    "实习生|工程师|开发工程师|算法工程师|测试工程师|前端工程师|后端工程师|客户端工程师|"
    "产品经理|产品助理|设计师|分析师|数据分析师|研究员|管培生|助理|专员|顾问|"
    "运营专员|运营经理|运营总监|运营主管|直播运营|主播运营专员|主播运营|"
    "经理|负责人|专家|主管|总监|架构师|科学家|审核员|编辑|策划|投放|销售|商务"
)
ROLE_KEYWORDS = (
    "算法|开发|前端|后端|客户端|测试|数据|产品|设计|运营|直播|主播|内容|策略|商业化|"
    "增长|市场|销售|商务|投放|品牌|电商|用户|项目|研究|管培|实习|工程师|分析师"
)


def guess_role(title, text):
    title = clean_text(title)
    title = re.sub(r"招聘.*$", "", title)
    parts = re.split(r"[-_|｜·—–]", title)
    for part in parts:
        part = clean_text(part)
        if 2 <= len(part) <= 32 and re.search(rf"(?:{ROLE_KEYWORDS}|{ROLE_SUFFIXES})", part):
            return clean_role_name(part)

    match = re.search(rf"([\u4e00-\u9fa5A-Za-z0-9/·（）() ]{{2,32}}(?:{ROLE_SUFFIXES}))", text)
    return clean_role_name(match.group(1)) if match else ""


def guess_company(meta, title, text):
    for key in ("og:site_name", "application-name", "author"):
        if meta.get(key):
            return clean_text(meta[key])

    title_parts = [clean_text(x) for x in re.split(r"[-_|｜·—–]", title) if clean_text(x)]
    for part in reversed(title_parts):
        if 2 <= len(part) <= 24 and not re.search(r"(招聘|岗位|职位|运营|经理|负责人|专家|主管)", part):
            return part

    match = re.search(r"(公司|品牌|企业)[:：]\s*([\u4e00-\u9fa5A-Za-z0-9（）()·\-]{2,30})", text)
    return clean_text(match.group(2)) if match else ""


def guess_salary(text):
    patterns = [
        r"(\d+(?:\.\d+)?\s*[-~—–]\s*\d+(?:\.\d+)?\s*[Kk])",
        r"(\d+(?:\.\d+)?\s*[Kk]\s*[-~—–]\s*\d+(?:\.\d+)?\s*[Kk])",
        r"(\d+(?:\.\d+)?\s*万\s*[-~—–]\s*\d+(?:\.\d+)?\s*万)",
        r"(\d+\s*[-~—–]\s*\d+\s*/\s*天)",
        r"(\d+\s*[-~—–]\s*\d+\s*元/天)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text or "")
        if match:
            return clean_text(match.group(1).replace(" ", ""))
    return ""


def clean_company_name(value):
    value = clean_text(value)
    value = value.strip(" 。.·-|")
    value = re.sub(r"^(例如|如|公司|企业|品牌)[:：]?", "", value).strip()
    value = re.sub(r"\s+(上海|北京|广州|深圳|杭州|南京|苏州|成都|重庆|武汉|西安|长沙|郑州|天津|宁波|厦门|青岛|合肥|佛山|东莞)$", "", value)
    value = re.sub(r"(?:\s*[·｜|]\s*)?(猎头顾问|招聘顾问|HR|刚刚活跃)$", "", value, flags=re.I).strip()
    return value


def clean_role_name(value):
    value = clean_text(value)
    value = re.sub(r"\d+(?:\.\d+)?\s*(?:[-~—–]\s*\d+(?:\.\d+)?)?\s*[Kk万]", " ", value)
    value = re.sub(r"\d+\s*[-~—–]\s*\d+\s*/\s*天", " ", value)
    value = re.sub(r"\d+\s*[-~—–]\s*\d+\s*元/天", " ", value)
    value = re.sub(r"\b\d+\s*[-~—–]\s*\d+\s*年\b", " ", value)
    value = re.sub(r"(经验不限|学历不限|本科|大专|硕士|博士|中专|高中|上海|北京|广州|深圳|杭州|南京|苏州|成都|重庆|武汉|西安|长沙)", " ", value)
    value = re.sub(r"^(猎头|急聘|精选|直聘|高薪|诚聘)[:：]?", "", value).strip()
    value = re.sub(r"\s+", " ", value).strip(" 。.·-|")
    return value[:60]


def looks_like_company_noise(value):
    value = clean_text(value)
    if not value:
        return False
    if re.fullmatch(r"(上海|北京|广州|深圳|杭州|南京|苏州|成都|重庆|武汉|西安|长沙|郑州|天津|宁波|厦门|青岛|合肥|佛山|东莞)", value):
        return True
    noise = re.compile(
        r"(立即沟通|收藏|微信|扫码|分享|举报|去App|查看更多|BOSS|猎聘|直聘|刚刚活跃|在线|活跃|"
        r"候选人|求职者|职位描述|岗位职责|任职要求|职位要求|工作内容)"
    )
    if noise.search(value):
        return True
    if re.search(r"(猎头公司|猎头顾问|招聘顾问|人力资源顾问|人才顾问|顾问)$", value):
        return True
    if re.search(r"^[\u4e00-\u9fa5]{2,4}\s*(V|v)?\s*(猎头|顾问|HR)?$", value):
        return True
    return False


def ocr_company_candidate(line):
    line = clean_company_name(line)
    line = line.strip(" -·|")
    if not (2 <= len(line) <= 36):
        return ""
    skip_words = re.compile(
        r"(薪|k|K|经验|学历|本科|大专|硕士|职位|岗位|职责|要求|福利|立即|沟通|收藏|投递|"
        r"Boss|BOSS|猎聘|直聘|刷新|发布|在线|活跃|微信|扫码|分享|举报|去App|查看更多|"
        r"上海$|北京$|广州$|深圳$|杭州$|南京$|苏州$|成都$|武汉$)"
    )
    if skip_words.search(line):
        return ""
    if re.search(rf"(?:{ROLE_KEYWORDS}|{ROLE_SUFFIXES})", line):
        return ""
    if looks_like_company_noise(line):
        return ""
    return line


def clean_jd_text(value):
    jd = trim_jd(value)
    stop_patterns = [
        r"\n?(微信扫码分享|举报|去App|与BOSS随时沟通|查看更多信息|查看更多信息|立即沟通|收藏).*",
        r"\n?[\u4e00-\u9fa5]{2,4}\s*(V|v)?\s*刚刚活跃.*",
    ]
    for pattern in stop_patterns:
        jd = re.sub(pattern, "", jd, flags=re.S)
    return jd[:9000].strip()


def normalize_job_result(result):
    data = dict(result or {})
    needs_review = []
    if isinstance(data.get("needsReview"), list):
        needs_review.extend(clean_text(item) for item in data["needsReview"] if clean_text(item))

    company = clean_company_name(data.get("company", ""))
    if looks_like_company_noise(company):
        company = ""
        needs_review.append("公司名可能混入招聘顾问或平台文案，请确认")

    role = clean_role_name(data.get("role", ""))
    salary = clean_text(data.get("salary", ""))
    if salary:
        salary = guess_salary(salary) or salary.replace(" ", "")
    city = clean_text(data.get("city", ""))
    experience = clean_text(data.get("experience", ""))
    education = clean_text(data.get("education", ""))
    jd = clean_jd_text(data.get("jd", ""))

    tags = data.get("tags") if isinstance(data.get("tags"), list) else []
    tags = [clean_text(item) for item in tags if clean_text(item)][:12]

    if not role:
        needs_review.append("岗位名称未能稳定识别")
    if not salary:
        needs_review.append("薪资未能稳定识别")

    data.update(
        {
            "ok": True,
            "company": company,
            "role": role,
            "salary": salary,
            "city": city,
            "experience": experience,
            "education": education,
            "jd": jd,
            "tags": tags,
            "needsReview": list(dict.fromkeys(needs_review))[:5],
        }
    )
    try:
        data["confidence"] = max(0, min(100, int(data.get("confidence") or 0)))
    except (TypeError, ValueError):
        data["confidence"] = 0
    return data


def extract_role_from_line(line):
    clean = re.sub(r"\d+(?:\.\d+)?\s*(?:[-~—–]\s*\d+(?:\.\d+)?)?\s*[Kk万]?", " ", line or "")
    clean = re.sub(r"\d+\s*[-~—–]\s*\d+\s*/\s*天", " ", clean)
    clean = re.sub(r"\d+\s*[-~—–]\s*\d+\s*元/天", " ", clean)
    clean = re.sub(r"(猎头|急聘|精选|直聘|招聘中|刚刚活跃|立即沟通|收藏)", " ", clean)
    clean = clean_text(clean)
    matches = re.findall(rf"([\u4e00-\u9fa5A-Za-z0-9/·（）() ]{{2,32}}(?:{ROLE_SUFFIXES}))", clean)
    if not matches:
        return ""
    return clean_role_name(matches[-1])


JD_HEADING_PATTERN = re.compile(
    r"^\s*(职位描述|职位详情|职位信息|岗位信息|岗位职责|工作职责|职责信息|任职要求|职位要求|岗位要求|工作内容|任职资格|岗位描述)\s*[:：]?\s*"
)


def strip_jd_heading(line):
    line = clean_text(line)
    stripped = JD_HEADING_PATTERN.sub("", line).strip()
    if stripped != line:
        return stripped
    return line


def looks_like_jd_content(line):
    line = strip_jd_heading(line)
    if not line:
        return False
    if re.match(r"^(\d+|[一二三四五六七八九十]+)[.、)]", line):
        return True
    if len(line) < 8:
        return False
    return bool(
        re.search(
            r"(负责|通过|完成|根据|协助|参与|制定|执行|维护|搭建|优化|提升|推动|跟进|运营|分析|"
            r"沟通|熟悉|了解|具备|能够|要求|优先|经验|能力|数据|产品|项目|销售|转化|复盘|"
            r"活动|内容|客户|用户|团队|策略|方案|流程)",
            line,
        )
    )


def looks_like_jd_noise(line):
    line = clean_text(line)
    if not line:
        return True
    if looks_like_jd_content(line):
        return False
    if looks_like_company_noise(line):
        return True
    if re.fullmatch(
        rf"(\d+(?:\.\d+)?\s*[-~—–]\s*\d+(?:\.\d+)?\s*[Kk万]?|"
        rf"\d+\s*[-~—–]\s*\d+\s*(?:元/天|/天)|"
        rf"\d+\s*[-~—–]\s*\d+年|经验不限|学历不限|本科|大专|硕士|博士|"
        rf"上海|北京|广州|深圳|杭州|南京|苏州|成都|武汉|{ROLE_SUFFIXES})",
        line,
    ):
        return True
    if len(line) <= 6 and not re.search(r"[.。；;、]", line):
        return True
    if re.search(r"(有限公司|公司|集团|科技|文化|传媒|广告|电商|品牌|上市|工作室)$", line):
        return True
    return False


def jd_quality_ok(jd):
    jd = clean_text(jd)
    if len(jd) < 18:
        return False
    if JD_HEADING_PATTERN.fullmatch(jd):
        return False
    return bool(looks_like_jd_content(jd) or re.search(r"(\n|。|；|;)", jd))


def score_jd_text(jd):
    jd = clean_text(jd)
    if not jd:
        return 0
    lines = [line for line in jd.splitlines() if line.strip()]
    content_hits = sum(1 for line in lines if looks_like_jd_content(line))
    heading_penalty = 10 if JD_HEADING_PATTERN.fullmatch(jd) else 0
    noise_penalty = sum(1 for line in lines if looks_like_jd_noise(line)) * 2
    length_score = min(30, len(jd) // 18)
    structure_score = min(20, len(lines) * 3)
    return length_score + structure_score + content_hits * 12 - heading_penalty - noise_penalty


def best_jd_from_texts(texts):
    candidates = []
    for text in texts:
        clean = clean_text(text)
        if not clean:
            continue
        jd = clean_jd_text(clean)
        candidates.append((score_jd_text(jd), jd))
    if not candidates:
        return ""
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def trim_jd(text):
    lines = []
    seen = set()
    for raw in clean_text(text).splitlines():
        line = raw.strip()
        if len(line) < 2:
            continue
        if line in seen:
            continue
        seen.add(line)
        lines.append(line)

    if not lines:
        return ""

    start_patterns = re.compile(r"(职位描述|职位详情|职位信息|岗位信息|岗位职责|工作职责|职责信息|任职要求|职位要求|岗位要求|工作内容|任职资格|岗位描述)")
    stop_patterns = re.compile(
        r"(微信扫码分享|举报|去App|与BOSS随时沟通|查看更多|立即沟通|收藏|职位发布者|职位发布人|"
        r"招聘者|联系人|公司介绍|企业介绍|工商信息|相似职位|推荐职位|附近职位|查看地图|"
        r"工作地址|面试地址|团队介绍|BOSS直聘|猎聘)"
    )
    start_index = next((index for index, line in enumerate(lines) if start_patterns.search(line)), -1)
    if start_index < 0:
        start_index = next((index for index, line in enumerate(lines) if looks_like_jd_content(line)), -1)
    if start_index < 0:
        start_index = 0
    started_from_heading = bool(start_patterns.search(lines[start_index]))

    picked = []
    for line in lines[start_index:]:
        if picked and stop_patterns.search(line):
            break
        if not picked and stop_patterns.search(line):
            continue
        if re.search(r"^[\u4e00-\u9fa5]{2,4}\s*(V|v)?\s*(刚刚活跃|在线|活跃)", line):
            break
        clean_line = strip_jd_heading(line)
        if not clean_line:
            continue
        if not picked and not started_from_heading and looks_like_jd_noise(clean_line):
            continue
        if started_from_heading and looks_like_jd_noise(clean_line):
            continue
        picked.append(clean_line)

    jd = "\n".join(picked)
    return jd[:9000].strip()


def fetch_url(url):
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("只支持 http/https 岗位链接")

    req = Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.7",
        },
    )
    with urlopen(req, timeout=16) as response:
        content_type = response.headers.get("Content-Type", "")
        raw = response.read(2_000_000)

    charset_match = re.search(r"charset=([\w.-]+)", content_type, re.I)
    charset = charset_match.group(1) if charset_match else "utf-8"
    try:
        return raw.decode(charset, errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")


def extract_job(url):
    html_text = fetch_url(url)
    structured = extract_structured(html_text)
    parser = PageTextParser()
    parser.feed(html_text)

    title = parser.meta.get("og:title") or parser.meta.get("twitter:title") or parser.title
    description = parser.meta.get("description") or parser.meta.get("og:description") or ""
    visible = parser.visible_text

    if structured:
        company = structured["company"] or guess_company(parser.meta, title, visible)
        role = structured["role"] or guess_role(title, visible)
        jd = structured["jd"] or trim_jd(visible)
        source = structured["source"]
    else:
        company = guess_company(parser.meta, title, visible)
        role = guess_role(title, visible)
        jd = trim_jd("\n".join([description, visible]))
        source = "html"

    return normalize_job_result({
        "ok": True,
        "company": company,
        "role": role,
        "jd": jd,
        "title": clean_text(title),
        "source": source,
    })


def guess_from_ocr_text(text):
    lines = [line.strip() for line in clean_text(text).splitlines() if line.strip()]
    joined = "\n".join(lines)
    role_candidates = []
    for index, line in enumerate(lines):
        role_candidate = extract_role_from_line(line)
        if role_candidate:
            role_candidates.append((role_candidate, index))

    role = ""
    if role_candidates:
        counts = {}
        for candidate, _ in role_candidates:
            counts[candidate] = counts.get(candidate, 0) + 1
        repeated = [item for item in role_candidates if counts[item[0]] > 1]
        description_index = next((i for i, line in enumerate(lines) if re.search(r"(职位描述|岗位职责|工作职责|任职要求)", line)), -1)
        if repeated:
            role = repeated[-1][0]
        elif description_index >= 0:
            before_description = [item for item in role_candidates if item[1] < description_index]
            role = min(before_description or role_candidates, key=lambda item: abs(item[1] - description_index))[0]
        else:
            role = role_candidates[0][0]
    else:
        role = guess_role("", joined)

    role_line_indexes = [index for candidate, index in role_candidates if candidate == role]
    salary_candidates = []
    for index, line in enumerate(lines):
        found = guess_salary(line)
        if found:
            salary_candidates.append((found, index))

    if role_line_indexes and salary_candidates:
        salary = min(
            salary_candidates,
            key=lambda item: min(abs(item[1] - role_index) for role_index in role_line_indexes),
        )[0]
    else:
        salary = guess_salary(joined)
    company = guess_company({}, "", joined)

    selected_index = -1
    if role_line_indexes:
        selected_index = role_line_indexes[-1]
    elif role:
        selected_index = next((i for i, line in enumerate(lines) if role in line), -1)
    if selected_index < 0 and salary:
        selected_index = next((i for i, line in enumerate(lines) if salary in line.replace(" ", "")), -1)

    if not company and selected_index >= 0:
        nearby_indexes = []
        nearby_indexes.extend(range(selected_index + 1, min(selected_index + 9, len(lines))))
        nearby_indexes.extend(range(max(0, selected_index - 4), selected_index))
        for index in nearby_indexes:
            candidate = ocr_company_candidate(lines[index])
            if not candidate:
                continue
            if re.search(r"(公司|集团|科技|文化|传媒|广告|电商|品牌|中心|门店|旗舰店|有限公司|上市|工作室|事务所)", candidate):
                company = candidate
                break
        if not company:
            for index in nearby_indexes:
                candidate = ocr_company_candidate(lines[index])
                if candidate:
                    company = candidate
                    break

    company_label_patterns = [
        r"(?:公司|企业|品牌|雇主|招聘方|所属公司)[:：]\s*([^\n]{2,32})",
        r"([^\n]{2,32})\s*(?:正在招聘|招聘中|直聘)",
    ]
    if not company:
        for pattern in company_label_patterns:
            match = re.search(pattern, joined)
            if match:
                company = clean_text(match.group(1))
                break

    if not company:
        for line in lines[:18]:
            if re.search(rf"(\d+(?:\.\d+)?\s*[-~—–]\s*\d+(?:\.\d+)?\s*[Kk]|{ROLE_KEYWORDS}|{ROLE_SUFFIXES})", line):
                continue
            if 2 <= len(line) <= 30 and re.search(r"(公司|集团|科技|文化|传媒|电商|品牌|中心|门店|旗舰店|有限公司|上市)", line):
                company = line
                break

    if not company and role:
        role_index = next((i for i, line in enumerate(lines) if role in line), -1)
        candidate_indexes = []
        if role_index >= 0:
            candidate_indexes.extend(range(role_index + 1, min(role_index + 8, len(lines))))
            candidate_indexes.extend(range(max(0, role_index - 4), role_index))
        candidate_indexes.extend(range(0, min(12, len(lines))))
        for index in candidate_indexes:
            company = ocr_company_candidate(lines[index])
            if company:
                break
    return clean_company_name(company), role, salary


def extract_ocr_from_data_url(data_url):
    match = re.match(r"data:(image/[\w.+-]+);base64,(.+)", data_url or "", re.S)
    if not match:
        raise ValueError("截图格式不正确")

    mime_type, payload = match.groups()
    suffix = {
        "image/png": ".png",
        "image/jpeg": ".jpg",
        "image/jpg": ".jpg",
        "image/webp": ".webp",
        "image/tiff": ".tiff",
    }.get(mime_type.lower(), ".img")

    image_bytes = base64.b64decode(payload)
    if len(image_bytes) > 12_000_000:
        raise ValueError("截图太大，请裁剪岗位详情区域后再上传")

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(image_bytes)
        tmp_path = Path(tmp.name)

    try:
        result = subprocess.run(
            [str(OCR_BINARY), str(tmp_path), "--json"] if OCR_BINARY.exists() else ["swift", str(OCR_SCRIPT), str(tmp_path), "--json"],
            cwd=str(ROOT),
            text=True,
            capture_output=True,
            timeout=45,
            check=False,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or "OCR 识别失败")
        output = clean_text(result.stdout)
        row_text = output
        column_text = ""
        try:
            payload = json.loads(output)
            row_text = clean_text(payload.get("rowText", ""))
            column_text = clean_text(payload.get("columnText", ""))
        except json.JSONDecodeError:
            pass
        text_candidates = [column_text, row_text]
        raw_text = row_text or column_text or output
        company, role, salary = guess_from_ocr_text(raw_text)
        if column_text:
            alt_company, alt_role, alt_salary = guess_from_ocr_text(column_text)
            company = company or alt_company
            role = role or alt_role
            salary = salary or alt_salary
        jd = best_jd_from_texts(text_candidates) or raw_text
        return normalize_job_result({
            "ok": True,
            "company": company,
            "role": role,
            "salary": salary,
            "jd": jd,
            "rawText": raw_text,
            "source": "ocr",
        })
    finally:
        try:
            tmp_path.unlink()
        except OSError:
            pass


def decode_data_url(data_url):
    match = re.match(r"data:([^;]+);base64,(.+)", data_url or "", re.S)
    if not match:
        raise ValueError("文件格式不正确")
    mime_type, payload = match.groups()
    return mime_type.lower(), base64.b64decode(payload)


def extract_docx_text(data):
    pieces = []
    with zipfile.ZipFile(io.BytesIO(data)) as docx:
        names = ["word/document.xml"]
        names.extend(name for name in docx.namelist() if name.startswith("word/header") or name.startswith("word/footer"))
        for name in names:
            if name not in docx.namelist():
                continue
            root = ElementTree.fromstring(docx.read(name))
            for elem in root.iter():
                if elem.tag.endswith("}t") and elem.text:
                    pieces.append(elem.text)
                elif elem.tag.endswith("}p"):
                    pieces.append("\n")
    return clean_text("".join(pieces))


def extract_plain_text(data):
    for encoding in ("utf-8", "utf-16", "gb18030"):
        try:
            return clean_text(data.decode(encoding))
        except UnicodeDecodeError:
            continue
    return clean_text(data.decode("utf-8", errors="replace"))


def extract_pdf_text(data):
    errors = []
    pieces = []
    try:
        import pdfplumber

        with pdfplumber.open(io.BytesIO(data)) as pdf:
            for page in pdf.pages:
                pieces.append(page.extract_text(x_tolerance=1, y_tolerance=3) or "")
        text = clean_text("\n".join(pieces))
        if len(text) >= 20:
            return text
    except Exception as exc:
        errors.append(f"pdfplumber: {exc}")

    pieces = []
    try:
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(data))
        for page in reader.pages:
            pieces.append(page.extract_text() or "")
        text = clean_text("\n".join(pieces))
        if len(text) >= 20:
            return text
    except Exception as exc:
        errors.append(f"pypdf: {exc}")

    pdftotext = shutil.which("pdftotext")
    if pdftotext:
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                tmp.write(data)
                tmp_path = tmp.name
            completed = subprocess.run(
                [pdftotext, "-layout", tmp_path, "-"],
                check=True,
                capture_output=True,
                text=True,
                timeout=30,
            )
            text = clean_text(completed.stdout)
            if len(text) >= 20:
                return text
        except Exception as exc:
            errors.append(f"pdftotext: {exc}")
        finally:
            if tmp_path:
                try:
                    Path(tmp_path).unlink()
                except OSError:
                    pass

    detail = "；".join(errors[:2])
    if detail:
        raise ValueError(f"PDF 文字提取失败：{detail}")
    raise ValueError("PDF 没有读取到足够文字，可能是扫描件图片版")


def extract_resume_file(file_info):
    name = clean_text(file_info.get("name") or "未命名简历")
    mime_type, data = decode_data_url(file_info.get("data", ""))
    suffix = Path(name).suffix.lower()
    if len(data) > 8_000_000:
        raise ValueError(f"{name} 太大，请上传 8MB 以内的简历")

    if suffix == ".pdf" or mime_type == "application/pdf":
        text = extract_pdf_text(data)
    elif suffix == ".docx" or "wordprocessingml" in mime_type:
        text = extract_docx_text(data)
    elif suffix in {".txt", ".md"} or mime_type.startswith("text/"):
        text = extract_plain_text(data)
    else:
        raise ValueError(f"{name} 暂不支持，请上传 PDF、DOCX、TXT 或 MD")

    if len(text) < 20:
        raise ValueError(f"{name} 没有读取到足够的简历文字")

    return {
        "name": name,
        "text": text[:60000],
    }


def extract_resumes(payload):
    files = payload.get("files") or []
    if not files:
        raise ValueError("请先选择一份或多份简历")
    if len(files) > 6:
        raise ValueError("一次最多上传 6 份简历")
    resumes = [extract_resume_file(item) for item in files]
    ai_options = ai_options_from_payload(payload)
    if ai_enabled(ai_options) and payload.get("ai", True):
        for resume in resumes:
            try:
                resume["ai"] = ai_analyze_resume_text(resume["name"], resume["text"], ai_options)
            except Exception as exc:
                resume["aiError"] = str(exc)
    return {"ok": True, "resumes": resumes}


def extract_job_from_image(data_url, ai_options=None):
    ai_options = ai_options or {}
    has_vision_model = bool(ai_options.get("visionModel") or (not ai_options.get("apiKey") and AI_VISION_MODEL))
    try:
        result = extract_ocr_from_data_url(data_url)
    except Exception as exc:
        if ai_enabled(ai_options) and has_vision_model:
            fallback = ai_extract_job_from_image(data_url, ai_options)
            fallback["source"] = "ai_vision_fallback"
            fallback.setdefault("needsReview", []).append(f"本地 OCR 失败，已使用 AI 兜底：{exc}")
            return fallback
        raise

    if jd_quality_ok(result.get("jd", "")):
        return result

    result.setdefault("needsReview", []).append("本地 OCR 未稳定截取到职位描述正文，请检查 JD")
    if ai_enabled(ai_options) and has_vision_model:
        try:
            fallback = ai_extract_job_from_image(data_url, ai_options)
            fallback["source"] = "ai_vision_fallback"
            fallback["rawText"] = result.get("rawText", "")
            fallback.setdefault("needsReview", []).append("本地 OCR 未稳定截取到 JD，已使用 AI 兜底")
            return fallback
        except Exception as exc:
            result.setdefault("needsReview", []).append(f"AI 兜底失败：{exc}")
    return result


class Handler(socketserver.StreamRequestHandler):
    def write_response(self, status, body, content_type="text/plain; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.wfile.write(f"HTTP/1.1 {status}\r\n".encode("ascii"))
        self.wfile.write(f"Content-Type: {content_type}\r\n".encode("ascii"))
        self.wfile.write(f"Content-Length: {len(body)}\r\n".encode("ascii"))
        self.wfile.write(b"Access-Control-Allow-Origin: *\r\n")
        self.wfile.write(b"Connection: close\r\n\r\n")
        self.wfile.write(body)

    def handle(self):
        request_line = self.rfile.readline().decode("iso-8859-1").strip()
        if not request_line:
            return
        method, target, _ = request_line.split(" ", 2)
        headers = {}
        while True:
            line = self.rfile.readline()
            if line in {b"\r\n", b"\n", b""}:
                break
            decoded = line.decode("iso-8859-1").strip()
            if ":" in decoded:
                key, value = decoded.split(":", 1)
                headers[key.lower()] = value.strip()

        if method == "POST":
            parsed = urlparse(target)
            if parsed.path == "/api/ocr":
                try:
                    length = int(headers.get("content-length", "0"))
                    raw = self.rfile.read(length)
                    payload = json.loads(raw.decode("utf-8"))
                    result = extract_job_from_image(payload.get("image", ""), ai_options_from_payload(payload))
                    self.write_response(200, json.dumps(result, ensure_ascii=False), "application/json; charset=utf-8")
                except Exception as exc:
                    result = {"ok": False, "error": str(exc)}
                    self.write_response(422, json.dumps(result, ensure_ascii=False), "application/json; charset=utf-8")
                return

            if parsed.path == "/api/resumes":
                try:
                    length = int(headers.get("content-length", "0"))
                    raw = self.rfile.read(length)
                    payload = json.loads(raw.decode("utf-8"))
                    result = extract_resumes(payload)
                    self.write_response(200, json.dumps(result, ensure_ascii=False), "application/json; charset=utf-8")
                except Exception as exc:
                    result = {"ok": False, "error": str(exc)}
                    self.write_response(422, json.dumps(result, ensure_ascii=False), "application/json; charset=utf-8")
                return

            if parsed.path == "/api/generate":
                try:
                    length = int(headers.get("content-length", "0"))
                    raw = self.rfile.read(length)
                    payload = json.loads(raw.decode("utf-8"))
                    result = ai_generate_application(payload)
                    self.write_response(200, json.dumps(result, ensure_ascii=False), "application/json; charset=utf-8")
                except Exception as exc:
                    result = {"ok": False, "error": str(exc)}
                    self.write_response(422, json.dumps(result, ensure_ascii=False), "application/json; charset=utf-8")
                return

            if parsed.path == "/api/test-ai":
                try:
                    length = int(headers.get("content-length", "0"))
                    raw = self.rfile.read(length)
                    payload = json.loads(raw.decode("utf-8"))
                    result = ai_test_config(payload)
                    self.write_response(200, json.dumps(result, ensure_ascii=False), "application/json; charset=utf-8")
                except Exception as exc:
                    result = {"ok": False, "error": str(exc)}
                    self.write_response(422, json.dumps(result, ensure_ascii=False), "application/json; charset=utf-8")
                return

            self.write_response(404, "Not Found")
            return

        if method != "GET":
            self.write_response(405, "Method Not Allowed")
            return

        parsed = urlparse(target)
        if parsed.path in {"/", "/resume-outreach-tool.html", "/api-key-mode.html"}:
            self.write_response(200, HTML_FILE.read_bytes(), "text/html; charset=utf-8")
            return

        if parsed.path == "/api/config":
            server_ai_enabled = ai_enabled()
            payload = {
                "ok": True,
                "aiEnabled": server_ai_enabled,
                "baseUrl": AI_BASE_URL if server_ai_enabled else "",
                "textModel": AI_TEXT_MODEL if server_ai_enabled else "",
                "visionModel": AI_VISION_MODEL if server_ai_enabled else "",
            }
            self.write_response(200, json.dumps(payload, ensure_ascii=False), "application/json; charset=utf-8")
            return

        if parsed.path == "/api/extract":
            qs = parse_qs(parsed.query)
            url = (qs.get("url") or [""])[0].strip()
            try:
                payload = extract_job(url)
                self.write_response(200, json.dumps(payload, ensure_ascii=False), "application/json; charset=utf-8")
            except (HTTPError, URLError, TimeoutError, ValueError) as exc:
                payload = {"ok": False, "error": str(exc)}
                self.write_response(422, json.dumps(payload, ensure_ascii=False), "application/json; charset=utf-8")
            except Exception as exc:
                payload = {"ok": False, "error": f"解析失败：{exc}"}
                self.write_response(500, json.dumps(payload, ensure_ascii=False), "application/json; charset=utf-8")
            return

        self.write_response(404, "Not Found")


class ReuseTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    with ReuseTCPServer((HOST, port), Handler) as httpd:
        print(f"Resume outreach tool: http://{HOST}:{port}/")
        httpd.serve_forever()


if __name__ == "__main__":
    main()
