---
name: resume-outreach-tool
description: Create and run a local Chinese resume outreach web app for job applications. Use when a user wants a shareable tool or webpage that supports PDF/DOCX resume upload, job screenshot OCR, job-resume matching, Boss/HR/business-owner greeting messages, optional OpenAI-compatible model settings, and phone access over the same WiFi.
---

# Resume Outreach Tool

## What This Skill Does

Create a local web app named `简历投递小帮手`. The app lets users upload resumes, upload job screenshots, analyze job fit, generate first-contact messages for Boss/HR/business owners, optionally configure an OpenAI-compatible model API, and open the same app from a phone on the same WiFi.

Use the bundled template in `assets/template/`. Do not rebuild the app from scratch unless the user asks for major product changes.

## Quick Start

Run the bundled creator script from this skill folder:

```bash
python3 scripts/create_resume_outreach_tool.py --target ./resume-outreach-tool --port 8766
```

For phone testing on the same WiFi:

```bash
python3 scripts/create_resume_outreach_tool.py --target ./resume-outreach-tool --port 8766 --lan
```

Then open the printed URL. `127.0.0.1` is only for the computer running the service; phones must use the computer's LAN IP.

## Created Files

The script copies these files into the target directory:

- `resume-outreach-tool.html`: the single-page web UI.
- `resume_tool_server.py`: the local HTTP service and APIs.
- `ocr_image.swift`: macOS Vision OCR helper for job screenshots.

The service serves `/`, `/resume-outreach-tool.html`, and `/api-key-mode.html` from the same HTML file.

## Core Features

- Resume library: upload one or more resumes; later uploads replace the saved resume library.
- Resume parsing: supports text PDF, DOCX, TXT, and MD. PDF scanning/image-only files need OCR or a model-based parser.
- Job input: upload a job screenshot or fill company, role, salary, and JD manually.
- Local OCR: on macOS, the Swift helper uses Apple Vision to read screenshots.
- Matching: calculates match score, recommendation degree, tags, evidence, and application advice.
- Greeting messages: generates separate first-contact copy for Boss, HR, and business owner audiences.
- Model settings: API Key is optional. If configured, the app tests the key and API before enabling model-enhanced resume analysis, matching, and wording optimization.
- Mobile preview: start with `--lan` and open `http://<computer-lan-ip>:8766/` on the phone.

## Environment Notes

- Local service requires Python 3.
- Local screenshot OCR requires macOS with Swift available. If Swift or Apple Vision is unavailable, use a configured vision model API as fallback or ask the user to provide text manually.
- The template can use bundled Codex Python packages for PDF parsing when available. On other machines, install `pdfplumber` or `pypdf` if PDF text extraction fails.
- Model APIs must be OpenAI-compatible chat completion endpoints. The user supplies provider, base URL, API Key, text model, and optional vision model.

## Recommended Workflow For Codex

1. Copy the template with `scripts/create_resume_outreach_tool.py`.
2. Start the local service unless the user only wants files exported.
3. Give the user the local URL.
4. If the user asks for phone testing, restart or start with `--lan`, then give the LAN URL.
5. If functionality fails, inspect browser console or service logs first, then patch the copied target files rather than the skill assets unless the user wants to update the skill.

## Updating The Skill

When the product changes, update the source app first, verify it, then copy the latest `resume-outreach-tool.html`, `resume_tool_server.py`, and `ocr_image.swift` into `assets/template/`. Re-run the skill validator after edits.
