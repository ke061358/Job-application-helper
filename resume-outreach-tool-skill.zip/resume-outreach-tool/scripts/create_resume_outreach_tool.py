#!/usr/bin/env python3
import argparse
import os
import shutil
import socket
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "assets" / "template"
FILES = ("resume-outreach-tool.html", "resume_tool_server.py", "ocr_image.swift")


def copy_template(target):
    target.mkdir(parents=True, exist_ok=True)
    for name in FILES:
        source = TEMPLATE / name
        if not source.exists():
            raise FileNotFoundError(f"Missing template file: {source}")
        shutil.copy2(source, target / name)
    return target


def lan_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("8.8.8.8", 80))
            return sock.getsockname()[0]
    except OSError:
        return ""


def compile_ocr(target):
    swiftc = shutil.which("swiftc")
    if not swiftc:
        return False, "swiftc not found; service will try running ocr_image.swift directly"
    try:
        subprocess.run(
            [swiftc, str(target / "ocr_image.swift"), "-o", str(target / "ocr_image")],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
        return True, "compiled ocr_image"
    except Exception as exc:
        return False, f"could not compile OCR helper: {exc}"


def main():
    parser = argparse.ArgumentParser(description="Create and optionally run the resume outreach tool.")
    parser.add_argument("--target", default="./resume-outreach-tool", help="Directory to create/update.")
    parser.add_argument("--port", type=int, default=8766, help="HTTP port.")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind when --lan is not used.")
    parser.add_argument("--lan", action="store_true", help="Bind to 0.0.0.0 for same-WiFi phone access.")
    parser.add_argument("--no-start", action="store_true", help="Only copy files; do not start the server.")
    parser.add_argument("--no-compile-ocr", action="store_true", help="Skip compiling the macOS OCR helper.")
    args = parser.parse_args()

    target = copy_template(Path(args.target).expanduser().resolve())
    print(f"Created resume outreach tool at: {target}")

    if not args.no_compile_ocr:
        ok, message = compile_ocr(target)
        print(("OK: " if ok else "Note: ") + message)

    host = "0.0.0.0" if args.lan else args.host
    local_url = f"http://127.0.0.1:{args.port}/"
    print(f"Local URL: {local_url}")
    if args.lan:
        ip = lan_ip()
        if ip:
            print(f"Phone URL: http://{ip}:{args.port}/")
        else:
            print("Phone URL: use your computer LAN IP with the selected port.")

    if args.no_start:
        return 0

    env = os.environ.copy()
    env["HOST"] = host
    print(f"Starting server on {host}:{args.port} ...")
    print("Press Ctrl+C to stop.")
    try:
        subprocess.run([sys.executable, "-B", str(target / "resume_tool_server.py"), str(args.port)], cwd=str(target), env=env)
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
